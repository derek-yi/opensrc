#ifndef __TCPECHO_H__
#define __TCPECHO_H__

void tcpecho_init(void);

#endif /* __TCPECHO_H__ */