#ifndef __TTCP_H__
#define __TTCP_H__

void TTCP_init(void);

#endif /* __TTCP_H__ */