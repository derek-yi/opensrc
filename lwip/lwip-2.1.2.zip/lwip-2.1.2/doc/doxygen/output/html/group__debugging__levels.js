var group__debugging__levels =
[
    [ "LWIP_DBG_FRESH", "group__debugging__levels.html#ga7d44d1804fa5e747aed86816e2a6cae0", null ],
    [ "LWIP_DBG_HALT", "group__debugging__levels.html#gab0a296414983155b30ad51871606b90f", null ],
    [ "LWIP_DBG_LEVEL_ALL", "group__debugging__levels.html#ga8ebaeb006b43f55897f3196b3617dc87", null ],
    [ "LWIP_DBG_LEVEL_SERIOUS", "group__debugging__levels.html#ga0269bdc51f1e8a5ecf9af72c6e1c996c", null ],
    [ "LWIP_DBG_LEVEL_SEVERE", "group__debugging__levels.html#gaab41143277cd38047b6660d90e9cec3b", null ],
    [ "LWIP_DBG_LEVEL_WARNING", "group__debugging__levels.html#ga77c491e468bf7d9a1bc48430c1866a96", null ],
    [ "LWIP_DBG_OFF", "group__debugging__levels.html#gadab1cdc3f45939a3a5c9a3d7e04987e1", null ],
    [ "LWIP_DBG_ON", "group__debugging__levels.html#ga9e31b7cbbc8f46af8e62b548079acd4e", null ],
    [ "LWIP_DBG_STATE", "group__debugging__levels.html#ga511ee3deb3240635f5ec6a1709c6d741", null ],
    [ "LWIP_DBG_TRACE", "group__debugging__levels.html#ga988147559b78642ac881815b66023646", null ]
];